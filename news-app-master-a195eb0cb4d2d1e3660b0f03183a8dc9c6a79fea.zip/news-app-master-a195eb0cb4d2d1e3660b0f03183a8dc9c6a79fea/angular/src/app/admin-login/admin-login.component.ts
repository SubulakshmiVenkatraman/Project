import { Component, OnInit } from '@angular/core';
import { AuthenticateService } from '../authenticate.service';
import { RouterModule, Routes } from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {
   user = 'Cognizant'
   pass = 'cts@123'
  invalidLogin = false
  constructor( private router: Router, private auth:AuthenticateService ) {
    console.log("i am in ts")
   }

  ngOnInit() {
    
    }
    checkLogin() {
      console.log("login >> "+this.auth.authenticate(this.user, this.pass))
     if (this.auth.authenticate(this.user, this.pass)
     ) {
       this.router.navigate(['/newsfeed'])
       this.invalidLogin = false
     } else
       this.invalidLogin = true
   }
 
 

}
