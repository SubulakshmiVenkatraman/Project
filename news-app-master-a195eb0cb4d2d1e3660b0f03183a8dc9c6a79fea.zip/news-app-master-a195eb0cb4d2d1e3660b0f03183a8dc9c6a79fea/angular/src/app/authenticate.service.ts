import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {
  
  authenticate(username, password) {
    if (username === "Cognizant" && password === "cts@123") {
      return true;
    } 
    else {
      return false;
    }
  }


}