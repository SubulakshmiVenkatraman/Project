import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '../../node_modules/@angular/common/http';
import { Observable } from '../../node_modules/rxjs';

const httpOptions = {
headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
providedIn: 'root'
})

export class BlacklistService {
adminUrl='/news';
blockUrl='/news';

constructor(private http:HttpClient) {
this.http =http;
}

list():Observable<any>
{
return this.http.get<any[]>(this.adminUrl,httpOptions);
}
blockUser(user):Observable<any>
{
return this.http.post<any[]>(this.blockUrl,user,httpOptions);
}
}
