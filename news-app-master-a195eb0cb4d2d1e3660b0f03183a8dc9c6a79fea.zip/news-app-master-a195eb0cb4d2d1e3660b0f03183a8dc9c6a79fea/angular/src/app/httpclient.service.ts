import { Injectable } from'@angular/core';
import { HttpClient } from'@angular/common/http';
import { Register } from './register.model';
import { Login } from'./login.model';

@Injectable({
providedIn: 'root'
})

export class HttpClientService {
constructor(private http:HttpClient) {}
private registerUrl ='';
public getRegister() {
return this.http.get<Register[]>(this.registerUrl);
}
public createRegister(reg) {
return this.http.post<Register>(this.registerUrl,reg);
}
private validationUrl ='';
public validation(){
    return this.http.get<Login[]>(this.validationUrl)
}
}
