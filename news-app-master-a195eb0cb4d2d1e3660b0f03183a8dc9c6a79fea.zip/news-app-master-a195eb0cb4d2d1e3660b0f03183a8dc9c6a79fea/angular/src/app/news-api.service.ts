import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
@Injectable({
   providedIn: 'root'
})
export class NewsApiService {

   api_key='ee5e30a72e864593a9fb3100d8de7dee';
language:String ='en';
   constructor( private http:HttpClient) { }

   initSources(){
     return this.http.get('https://newsapi.org/v2/sources?apiKey='+this.api_key);
   }

   initArtcles(){
     return this.http.get('https://newsapi.org/v2/top-headlines?country=us&apiKey='+this.api_key);
   }

   initEverything(){
     return this.http.get('https://newsapi.org/v2/everything?q=bitcoin&apiKey='+this.api_key);
   }
     
    getArticleByLanguage(language: String){
    console.log(language);
    this.language = language;

  }
  getArticlesByID(source: String){
   return this.http.get('https://newsapi.org/v2/top-headlines?sources='+source+'&apiKey='+this.api_key);
  }
  getArticlesByKeyword(keyword:String)
  {
    return this.http.get('https://newsapi.org/v2/everything?q='+keyword+'&apiKey='+this.api_key);
  }
  
}
