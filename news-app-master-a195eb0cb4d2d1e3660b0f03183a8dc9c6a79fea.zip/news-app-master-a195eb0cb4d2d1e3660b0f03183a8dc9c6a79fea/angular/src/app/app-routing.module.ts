import { NgModule } from '@angular/core';
import * as router from '@angular/router';
import { LoginComponent } from './login/login.component';

import { FavouriteComponent } from './favourite/favourite.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';


import { NewsfeedComponent } from './newsfeed/newsfeed.component';

const routes: router.Routes = [
  {path:'', redirectTo:'login', pathMatch:'full'},
  {path:'login', component:LoginComponent},
  {path:'favourite', component:FavouriteComponent},
  {path:'sign-up', component:SignUpComponent},
  {path:'admin-login', component:AdminLoginComponent},
  {path:'newsfeed', component:NewsfeedComponent },
 
];

@NgModule({
  imports: [router.RouterModule.forRoot(routes)],
  exports: [router.RouterModule]
})
export class AppRoutingModule { }
