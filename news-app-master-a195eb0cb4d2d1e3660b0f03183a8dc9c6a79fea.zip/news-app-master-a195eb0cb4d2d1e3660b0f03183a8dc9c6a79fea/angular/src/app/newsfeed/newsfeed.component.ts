import { Component } from '@angular/core';
import { NewsApiService } from '../news-api.service';
import {FormControl} from '@angular/forms';
import { FormsModule } from '@angular/forms';
import {MatExpansionModule} from '@angular/material/expansion';
@Component({
  selector: 'app-newsfeed',
  templateUrl: './newsfeed.component.html',
  styleUrls: ['./newsfeed.component.css']
})
export class NewsfeedComponent {
  mArticles: any;
  mSources:any;
  language: string = null;
  keyword: string = null; 


  constructor( private newsapi:NewsApiService){
    console.log('app component constructor called');   

  }

  ngOnInit(){

    this.newsapi.initArtcles().subscribe(data => this.mArticles= data['articles']);   
  
  this.newsapi.initSources().subscribe(data=> this.mSources = data['sources']);
}

  searchArticles(source){
    console.log("selected source is: "+source);
    this.newsapi.getArticlesByID(source).subscribe(data => this.mArticles = data['articles']);
  }
searchArticleByKeyword(){
  console.log("selected keyword is: "+this.keyword);
    this.newsapi.getArticlesByKeyword(this.keyword).subscribe(data => this.mArticles = data['articles']);
}
searchArticleByLanguage(){
  console.log("selected keyword is: "+this.language);
  
    this.newsapi.getArticleByLanguage(this.language);  
    this.ngOnInit();
}

}
