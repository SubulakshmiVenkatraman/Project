import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RouterModule, Routes } from '@angular/router';
import { FavouriteComponent } from './favourite/favourite.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { NewsApiService } from './news-api.service';
import { AuthenticateService} from './authenticate.service';
import { HttpClientService } from './httpclient.service';
import { MatButtonModule, MatCardModule, MatMenuModule, MatToolbarModule, MatIconModule, MatSidenavModule, MatListModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { from } from 'rxjs';
import { NewsfeedComponent } from './newsfeed/newsfeed.component';
import {MatExpansionModule} from '@angular/material/expansion';




@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    
    FavouriteComponent,
    SignUpComponent,
    AdminLoginComponent,
    NewsfeedComponent,
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatButtonModule,
    MatMenuModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    RouterModule, 
    MatExpansionModule,
    FormsModule,
 HttpClientService


  

  ],
  providers: [NewsApiService,AuthenticateService],
  bootstrap: [AppComponent]
})
export class AppModule {
  matAccordion;
  matExpansionPanel;
 }
