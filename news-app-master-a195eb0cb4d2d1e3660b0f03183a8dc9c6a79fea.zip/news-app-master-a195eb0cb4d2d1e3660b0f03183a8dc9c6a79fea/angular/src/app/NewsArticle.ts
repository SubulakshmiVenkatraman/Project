export class NewsArticle{
    title:string;
    description:string;
    content:string;
    PublishedAtDate:string
    }
