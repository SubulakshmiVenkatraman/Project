package com.cts.service;

import java.util.List;

import com.cts.entity.Login;
import com.cts.entity.Register;

public interface LoginService {
	
	public String signUp(Register register);

	public boolean Validate(Login login);

	public static String deleteAnalyst(String username) {
		// TODO Auto-generated method stub
		return null;
	}
	public static String getAnalyst(String username) {
		// TODO Auto-generated method stub
		return null;
	}
	public static String blacklist(Login login) {
		// TODO Auto-generated method stub
		return null;
	}
	
}