
/**
 * 
 */
package com.cts.service;

 

import java.util.List;

 

import javax.transaction.Transactional;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.dao.FavouriteDaoImpl;
import com.cts.entity.Favourite;

 

@Service("favouriteService")

public class FavouriteServiceImpl implements FavouriteService{

 

       @Autowired //To create object

       private FavouriteDaoImpl favouriteDao;

public List<Favourite> listAllNewsArticle() {

System.out.println("I am in service");
    return favouriteDao.listnewsArticle();
}

public String delete(String title) {

return (String) favouriteDao.delete(title);
}

public String get(String title) {

  String favourite = favouriteDao.get(title);

          System.out.println("service newsArticle "+favourite.getClass());

          return favourite;
// TODO Auto-generated method stub
}

@Override
public Favourite add(Favourite favourite) {
	// TODO Auto-generated method stub
	System.out.println("add method in service");
	    return (Favourite) favouriteDao.add(favourite);
}
}
