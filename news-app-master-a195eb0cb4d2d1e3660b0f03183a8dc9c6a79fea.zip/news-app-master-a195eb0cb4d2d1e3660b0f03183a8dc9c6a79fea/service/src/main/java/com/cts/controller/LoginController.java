package com.cts.controller;

 

import java.io.IOException;

import java.util.List;

 

import javax.servlet.ServletConfig;

import javax.servlet.ServletException;

import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServlet;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

 

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.servlet.ModelAndView;

 

import com.cts.entity.Login;

import com.cts.entity.Register;

import com.cts.service.LoginService;

 

@RestController

@CrossOrigin(origins = "http://localhost:4200")

@RequestMapping( "/logging")

public class LoginController {

 

    // standard constructors

     @Autowired

    LoginService loginService ;

    Login login;

   

    @PostMapping("/login")

    public String login(Login login) {

        loginService.Validate(login);

        System.out.println("login");

        return "login";

    }

  

 

    @PostMapping({"/", "/welcome"})

    public String welcome(Model model) {

        return "welcome";

    }

   

    @PostMapping("/deleteAnalyst")

    public String deleteAnalyst(@RequestParam("username") String username)

    {

                String deleteAnalyst = LoginService.deleteAnalyst(username);

                    return "username"; }

 

    @PostMapping("/getAnalyst")

    public String getAnalyst(@RequestParam("username") String username)

    {

                String getAnalyst = LoginService.getAnalyst(username);

                    return "username"; }
    @PostMapping("/blacklist")

    public String blacklist(Login login)

    {

                String blacklist = LoginService.blacklist(login);

                    return blacklist; }

 

}