package com.cts.dao;

import com.cts.entity.Login;
import com.cts.entity.Register;

public interface LoginDao {
	
	public String signUp(Register register);

	public boolean validation(Login login);

	void deleteAnalyst(String username);

	Login getAnalyst(String username);

	void blacklist(Login login);

}