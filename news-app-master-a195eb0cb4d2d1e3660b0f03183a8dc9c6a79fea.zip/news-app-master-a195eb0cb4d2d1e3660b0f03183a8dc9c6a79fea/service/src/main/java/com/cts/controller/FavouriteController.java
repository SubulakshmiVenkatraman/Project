package com.cts.controller;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.entity.Favourite;
import com.cts.service.FavouriteServiceImpl;

 
@CrossOrigin(origins = "http://localhost:4200")

@RestController

@RequestMapping( "/news")

public class FavouriteController {

       @Autowired

       private FavouriteServiceImpl newsArticleService;

       @RequestMapping("/")

       public String first() {

           return "spring boot application";

    }
    

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    
   
    public ResponseEntity<List<Favourite>> listAllArticle(){
     List<Favourite> listNews=this.newsArticleService.listAllNewsArticle();
return new ResponseEntity<List<Favourite>>(listNews, HttpStatus.OK);
      
    }
    
    @GetMapping("/get") public String get(@RequestParam("title") String title) {

    newsArticleService.get(title);

         return "newsArticle";

     }
    
    
    @GetMapping("/add") public Favourite add(Favourite newsArticle){

        return (Favourite) newsArticleService.add(newsArticle);

    }
    @GetMapping("/delete") public String delete(@RequestParam("title")

    String title) {

     newsArticleService.delete(title);

     return "newsArticle";

     }

}
