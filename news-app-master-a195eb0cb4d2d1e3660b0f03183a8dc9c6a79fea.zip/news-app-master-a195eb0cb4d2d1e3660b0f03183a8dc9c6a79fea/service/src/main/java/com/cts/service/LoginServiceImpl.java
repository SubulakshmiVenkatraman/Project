package com.cts.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.dao.LoginDao;

import com.cts.entity.Login;
import com.cts.entity.Register;
@Service("loginservice")
public class LoginServiceImpl implements LoginService{
	
	@Autowired 
	LoginDao loginDao;
	
	@Override
	@Transactional
	public String signUp(Register register) {
		String values = loginDao.signUp(register);
		return values;
	}

	@Override
	public boolean Validate(Login login) {
		return loginDao.validation(login);
	}
		
	@Transactional
	public Login getAnalyst(String username) {
		Login login = loginDao.getAnalyst(username);
		System.out.println("service analyst "+login.getUsername());
		return login;
	}

	@Transactional
	public void deleteAnalyst(String username) {
		loginDao.deleteAnalyst(username);
	}
	@Transactional
	public void blacklist(Login login) {
		loginDao.blacklist(login);
	}



}
