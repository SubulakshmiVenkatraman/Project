package com.cts.service;

import java.util.List;
import com.cts.entity.Favourite;

public interface FavouriteService {
       Favourite add(Favourite favourite);
       List<Favourite> listAllNewsArticle();
       public String get(String title);
       public String delete(String title);
       
}
