package com.cts.dao;



import java.util.List;



import com.cts.entity.Favourite;



public interface FavouriteDao {

            Favourite add(Favourite newsArticle);

            List<Favourite> listnewsArticle();

            String get(String title);

            String delete(String title);

           

}
