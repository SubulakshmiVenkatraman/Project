
package com.cts.dao;

import java.util.ArrayList;
import java.util.List;

 

import javax.persistence.criteria.CriteriaBuilder;

import javax.persistence.criteria.CriteriaQuery;

import javax.persistence.criteria.Root;

 

import org.hibernate.Session;

import org.hibernate.SessionFactory;

import org.hibernate.query.Query;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;

 

import com.cts.entity.Favourite;;


@Repository("favouriteDao")

public class FavouriteDaoImpl implements FavouriteDao{
	
       @Autowired

       SessionFactory sessionFactory;

       public Favourite add(Favourite favourite) {
// TODO Auto-generated method stub
sessionFactory.getCurrentSession().saveOrUpdate(favourite);
         System.out.println("Add method in Dao");
         return favourite ;
}




@Override
public List<Favourite> listnewsArticle() {
	List<Favourite> listNews= new ArrayList<Favourite>();
    System.out.println("hello" +sessionFactory);

   Session session = sessionFactory.getCurrentSession();
     listNews= session.createQuery("from Registration").list();
 
    if (listNews.size()>0){
     return listNews;
          }else
     {
    return null;
     }
}




@Override
public String get(String title) {
	Favourite favourite = null;

    try{

           Session session = sessionFactory.getCurrentSession();

           favourite = session.get(Favourite.class, title);

           System.out.println("Favourite title was "+title+" Object is "+favourite);

           if(favourite==null){

                

                 System.out.println("article does not exist");

           }

    }catch(Exception exception){

           exception.printStackTrace();
    }

    return null;
}

@Override
public String delete(String title) {
	Session session = sessionFactory.getCurrentSession();
    Favourite  favourite = (Favourite )session.load(Favourite .class, title);
      session.delete(favourite);
    return title;
}


}

