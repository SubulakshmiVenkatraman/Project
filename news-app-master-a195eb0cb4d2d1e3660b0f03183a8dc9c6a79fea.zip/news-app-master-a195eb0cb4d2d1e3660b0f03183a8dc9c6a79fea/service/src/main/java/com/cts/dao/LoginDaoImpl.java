package com.cts.dao;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.entity.Login;
import com.cts.entity.Register;

import javassist.bytecode.Descriptor.Iterator;


@Repository("userDao")
public class LoginDaoImpl implements LoginDao {

@Autowired 
SessionFactory sessionFactory;
Login login;

@Override
public String signUp(Register register){
sessionFactory.getCurrentSession().save(register);
System.out.println("successfully registered");
return "successfully registered";
}
@Override
public boolean validation(Login login) {
   /* String username=login.getUsername();
    String password=login.getPassword();*/
    boolean var=false;
    try {
       
                 Session session = sessionFactory.getCurrentSession();
    session.beginTransaction();
    String hql = "select  from Login where username= :username and  password= :password";
    Query query = session.createQuery(hql);
    query.setParameter("username", login.getUsername());
    query.setParameter("password", login.getPassword());

    int status=query.executeUpdate();
    if(status ==1){
                var= true;
    }
    else{
                var= false;
    }
} catch (HibernateException e) {
    
    
} finally {
   
}
    return var;
    }

@Override
public Login getAnalyst(String username) {
     Login login = null;
     try{
           Session session = sessionFactory.getCurrentSession();
           login = session.get(Login.class, username);
           System.out.println("User "+username+" Object is "+login);
           if(login==null){
                 System.out.println("No such analyst found");
            }
             }catch(Exception exception){
                   exception.printStackTrace();
                 }
              return login;
           }
                                                                
@Override
public void deleteAnalyst(String username) {
        Session session = sessionFactory.getCurrentSession();
        Login login = (Login)session.load(Login.class, username);
                                session.delete(login);
                }

@Override
public void blacklist(Login login){
	Session session=sessionFactory.getCurrentSession();
	Query query=session.createQuery("UPDATE from Login set where");
	int result=query.executeUpdate();
}
}
