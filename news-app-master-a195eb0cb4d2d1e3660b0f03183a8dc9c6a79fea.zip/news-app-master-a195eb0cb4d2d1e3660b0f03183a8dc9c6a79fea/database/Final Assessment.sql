create database final_assessment;
use final_assessment;
create table Registration(
username varchar(80),
password varchar(60),
confirmpassword varchar(60),
phone int(255) primary key,
email varchar(50),
language varchar(40)
);


create table myfavourite(
title varchar(80),
description varchar(60),
content varchar(60),
published_At_Date int(255)

);
